SELECT * FROM data;
